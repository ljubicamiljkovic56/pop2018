﻿using ProjekatWPF.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProjekatWPF
{
    /// <summary>
    /// Interaction logic for EditKorisnici.xaml
    /// </summary>
    public partial class EditKorisnici : Window
    {
        public enum Opcija { DODAVANJE, IZMENA};
        private Korisnik korisnik;
        private Opcija opcija;
        public EditKorisnici(Korisnik korisnik, Opcija opcija)
        {
            InitializeComponent();
            this.korisnik = korisnik;
            this.opcija = opcija;

            this.DataContext = korisnik;
            CbPol.ItemsSource = Aplikacija.Instance.PolLista;
            CbTipKorisnika.ItemsSource = Aplikacija.Instance.TipLista; 

            if (opcija.Equals(Opcija.IZMENA))
            {
                TxtKorisnickoIme.IsEnabled = false;
            }
        }
        private void BtnSacuvaj_Click(Object sender, RoutedEventArgs e)
        {
            if (!Validation.GetHasError(TxtEmail))
            {
                this.DialogResult = true;
                if (opcija.Equals(Opcija.DODAVANJE) && !PostojiKorisnik(korisnik.KorisnickoIme))
                {
                    korisnik.Sacuvaj();
                }
            }
            
        }
        private void BtnOdustani_Click(Object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }
        private bool PostojiKorisnik(String korisnickoIme)
        {
            foreach(Korisnik korisnik in Aplikacija.Instance.Korisnici)
            {
                if(korisnik.KorisnickoIme.Equals(korisnickoIme))
                {
                    return true;
                }
            }
            return false;
        }
    }
}
