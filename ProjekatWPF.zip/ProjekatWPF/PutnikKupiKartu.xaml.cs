﻿using ProjekatWPF.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProjekatWPF
{
    /// <summary>
    /// Interaction logic for PutnikKupiKartu.xaml
    /// </summary>
    public partial class PutnikKupiKartu : Window
    {
        ICollectionView view;

        public enum Opcija { DODAVANJE, IZMENA };
        private Karta karta;
        private Opcija opcija;
        public PutnikKupiKartu(Karta karta, Opcija opcija = Opcija.DODAVANJE)
        {

            InitializeComponent();
            view = CollectionViewSource.GetDefaultView(Aplikacija.Instance.Karte);
            DGKarte.ItemsSource = view;
            DGKarte.IsSynchronizedWithCurrentItem = true;
            DGKarte.ColumnWidth = new DataGridLength(1, DataGridLengthUnitType.Star);

            this.karta = karta;
            this.opcija = opcija;

            this.DataContext = karta;


        }
        private void BtnKupi_Click(object sender, RoutedEventArgs e)
        {
            PutnikKupi putnikKupi = new PutnikKupi();
            putnikKupi.ShowDialog();
        }
        private void BtnNazad_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }
    }
}
