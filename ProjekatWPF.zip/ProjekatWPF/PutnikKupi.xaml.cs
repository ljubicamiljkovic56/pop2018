﻿using ProjekatWPF.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProjekatWPF
{
    /// <summary>
    /// Interaction logic for PutnikKupi.xaml
    /// </summary>
    public partial class PutnikKupi : Window
    {
        public PutnikKupi()
        {
            InitializeComponent();
        }
        private void BtnKupi_Click(object sender, RoutedEventArgs e)
        {
            EditKarte editKarte = new EditKarte(new Karta(), EditKarte.Opcija.DODAVANJE);
            editKarte.ShowDialog();
        }

    }
}
