﻿select * from Aerodromi
select * from Aviokompanije
select * from Avioni
select * from Karte
select * from Korisnici
select * from Letovi
select * from Sedista

insert into Aerodromi (Naziv, Grad, Sifra, [Active ]) VALUES ('Amsterdam Aerodrom', 'Amsterdam', 'AMS',1);
insert into Aerodromi (Naziv, Grad, Sifra, [Active ]) VALUES ('Nikola Tesla', 'Beograd', 'BEG', 1);
insert into Aerodromi (Naziv, Grad, Sifra, [Active ]) VALUES ('London Aerodrom', 'London', 'LON', 1);

insert into Aviokompanije(Sifra, [Active ]) VALUES ('A1',1);
insert into Aviokompanije(Sifra, [Active ]) VALUES ('A2', 1);
insert into Aviokompanije(Sifra, [Active ]) VALUES ('A3', 1);

insert into Avioni(Pilot, Broj_leta, Naziv_aviokompanije, [Active ]) VALUES ('P1','B1','A1',1);
insert into Avioni(Pilot, Broj_leta, Naziv_aviokompanije, [Active ]) VALUES ('P2','B2','A2',1);
insert into Avioni(Pilot, Broj_leta, Naziv_aviokompanije, [Active ]) VALUES ('P3','B3','A3',1);

insert into Karte(Broj_leta, Broj_sedista, Naziv_putnika, Odrediste, Destinacija, Kapija, Ukupna_cena_karte, [Active ]) VALUES ('01','11','ekonomski','Atina','Grcka','G1',20000.00,1);
insert into Karte(Broj_leta, Broj_sedista, Naziv_putnika, Odrediste, Destinacija, Kapija, Ukupna_cena_karte, [Active ]) VALUES ('02','12','biznis','Rim','Italija','G2',18000.00,1);
insert into Karte(Broj_leta, Broj_sedista, Naziv_putnika, Odrediste, Destinacija, Kapija, Ukupna_cena_karte, [Active ]) VALUES ('03','13','ekonomski','Bec','Austrija','G3',18500.00,1);

insert into Korisnici(Korisnicko_ime, Lozinka, Ime, Prezime, Pol, Email, Adresa_stanovanja, Tip_korisnika, [Active ]) VALUES ('pera','pera','Pera','Peric','MUSKI','pera@yahoo.com','Novi Sad','ADMINISTRATOR',1);
insert into Korisnici(Korisnicko_ime, Lozinka, Ime, Prezime, Pol, Email, Adresa_stanovanja, Tip_korisnika, [Active ]) VALUES ('mika','mika','Mika','Mikic','MUSKI','mika@gmail.com','Beograd','PUTNIK',1);
insert into Korisnici(Korisnicko_ime, Lozinka, Ime, Prezime, Pol, Email, Adresa_stanovanja, Tip_korisnika, [Active ]) VALUES ('zika','zika','Zika','Zikic','MUSKI','zika@hotmail.com','Subotica','PUTNIK',1);

insert into Letovi(Broj_leta, Odrediste, Destinacija, Cena_leta, [Active ]) VALUES ('01','Atina','Grcka',20000.00,1);
insert into Letovi(Broj_leta, Odrediste, Destinacija, Cena_leta, [Active ]) VALUES ('02','Rim','Italija',18000.00,1);
insert into Letovi(Broj_leta, Odrediste, Destinacija, Cena_leta, [Active ]) VALUES ('03','Bec','Austrija',18500.00,1);

insert into Sedista(Broj_sedista, [Active ]) VALUES ('11',1);
insert into Sedista(Broj_sedista, [Active ]) VALUES ('12',1);
insert into Sedista(Broj_sedista, [Active ]) VALUES ('13',1);