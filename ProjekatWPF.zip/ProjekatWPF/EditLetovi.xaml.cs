﻿using ProjekatWPF.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProjekatWPF
{
    /// <summary>
    /// Interaction logic for EditLetovi.xaml
    /// </summary>
    public partial class EditLetovi : Window
    {
        public enum Opcija { DODAVANJE, IZMENA };
        private Let let;
        private Opcija opcija;
        public EditLetovi(Let let, Opcija opcija)
        {
            InitializeComponent();
            this.let = let;
            this.opcija = opcija;

            this.DataContext = let;
            CbDestinacija.ItemsSource = Aplikacija.Instance.Aerodromi.Where(a => a.Active).Select(a => a.Sifra);
            CbOdrediste.ItemsSource = Aplikacija.Instance.Aerodromi.Where(a => a.Active).Select(a => a.Sifra);

            if (opcija.Equals(Opcija.IZMENA))
            {

                TxtBrojLeta.IsEnabled = false;
               
            }
        }

        private void BtnSacuvaj_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
            if(opcija.Equals(Opcija.DODAVANJE) && !PostojiLet(let.BrojLeta))
            {
                let.Sacuvaj();
            }
        }

        private void BtnOdustani_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }
        private bool PostojiLet(String brojLeta)
        {
            foreach(Let let in Aplikacija.Instance.Letovi)
            {
                if(let.BrojLeta.Equals(brojLeta))
                {
                    return true;
                }
            }
            return false;
        }
    }
}
