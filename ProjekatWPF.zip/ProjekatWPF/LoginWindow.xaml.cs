﻿using ProjekatWPF.Enumeracije;
using ProjekatWPF.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProjekatWPF
{
    /// <summary>
    /// Interaction logic for LoginWindow.xaml
    /// </summary>
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }
        private void btnPotvrdi_Click(object sender, RoutedEventArgs e)
        {
            bool Postoji = false;
            foreach(var korisnik in Aplikacija.Instance.Korisnici)
            {
                if(korisnik.KorisnickoIme.Equals(txtKorisnickoIme.Text) && korisnik.Lozinka.Equals(txtLozinka.Text))
                {
                    if (korisnik.TipKorisnika.Equals(ETipKorisnika.ADMINISTRATOR))
                    {
                        MainWindow mainWindow = new MainWindow();
                        mainWindow.Show();
                    }
                    else
                    {
                        PutnikWindow putnikWindow = new PutnikWindow();
                        putnikWindow.Show();
                    }
                    Aplikacija.Instance.UlogovanKorisnik = korisnik;
                    Postoji = true;
                    break;
                }
                else
                {
                    Postoji = false;
                }

            }
            if (!Postoji)
            {
                MessageBox.Show("Ne postoji korisnik sa takvim kredencijalima.");
            }
        }
            
    }
}
