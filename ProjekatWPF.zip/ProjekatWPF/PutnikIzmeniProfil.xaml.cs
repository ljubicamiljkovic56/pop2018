﻿using ProjekatWPF.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProjekatWPF
{
    /// <summary>
    /// Interaction logic for PutnikIzmeniProfil.xaml
    /// </summary>
    public partial class PutnikIzmeniProfil : Window
    {
        public enum Opcija { DODAVANJE, IZMENA };
        private Korisnik ulogovanKorisnik;
        private Opcija opcija;
        

        public PutnikIzmeniProfil(Korisnik ulogovanKorisnik, Opcija opcija = Opcija.IZMENA)
        {
            InitializeComponent();
            this.ulogovanKorisnik = ulogovanKorisnik;
            this.opcija = opcija;

            this.DataContext = ulogovanKorisnik;
            CbPol.ItemsSource = Aplikacija.Instance.PolLista;
            CbTipKorisnika.ItemsSource = Aplikacija.Instance.TipLista;

            if (opcija.Equals(Opcija.IZMENA))
            {
                TxtKorisnickoIme.IsEnabled = false;
            }
        }


        private void BtnSacuvaj_Click(Object sender, RoutedEventArgs e)
        {
            if (!Validation.GetHasError(TxtEmail))
            {
                this.DialogResult = true;
                if (opcija.Equals(Opcija.DODAVANJE) && !PostojiKorisnik(ulogovanKorisnik.KorisnickoIme))
                {
                    ulogovanKorisnik.Sacuvaj();
                }
            }

        }
        private void BtnOdustani_Click(Object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }
        private bool PostojiKorisnik(String korisnickoIme)
        {
            foreach (Korisnik korisnik in Aplikacija.Instance.Korisnici)
            {
                if (korisnik.KorisnickoIme.Equals(korisnickoIme))
                {
                    return true;
                }
            }
            return false;
        }
    }
}
