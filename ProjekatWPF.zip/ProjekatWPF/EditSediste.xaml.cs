﻿using ProjekatWPF.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProjekatWPF
{
    /// <summary>
    /// Interaction logic for EditSediste.xaml
    /// </summary>
    public partial class EditSediste : Window
    {
        public enum Opcija { DODAVANJE, IZMENA };
        private Sediste sediste;
        private Opcija opcija;
        public EditSediste(Sediste sediste, Opcija opcija)
        {
            InitializeComponent();
            this.sediste = sediste;
            this.opcija = opcija;

            this.DataContext = sediste;

            if (opcija.Equals(Opcija.IZMENA))
            {
                TxtId.IsEnabled = true;
            }
        }
        private void BtnSacuvaj_Click(Object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
            if(opcija.Equals(Opcija.DODAVANJE) && !PostojiSediste(sediste.BrojSedista))
            {
                sediste.Sacuvaj();
            }
        }
        private void BtnOdustani_Click(Object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }
        private bool PostojiSediste(String id)
        {
            foreach(Sediste sediste in Aplikacija.Instance.Sedista)
            {
                if(sediste.Id.Equals(id))
                {
                    return true;
                }
            }
            return false;
        }
    }
}
