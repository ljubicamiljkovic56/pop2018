﻿using ProjekatWPF.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProjekatWPF
{
    /// <summary>
    /// Interaction logic for EditAvioni.xaml
    /// </summary>
    public partial class EditAvioni : Window
    {
        ICollectionView view1;
        ICollectionView view2;

        public enum Opcija { DODAVANJE, IZMENA };
        private Avion avion;
        private Opcija opcija;
        public EditAvioni(Avion avion, Opcija opcija)
        {
            InitializeComponent();
            this.avion = avion;
            this.opcija = opcija;

            this.DataContext = avion;

            if(opcija.Equals(Opcija.IZMENA))
            {
                TxtBrojLeta.IsEnabled = false;
            }
            
            view1 = CollectionViewSource.GetDefaultView(Aplikacija.Instance.SedistaEkonomskeKlase);
            view2 = CollectionViewSource.GetDefaultView(Aplikacija.Instance.SedistaBiznisKlase);
            // view.Filter = CustomFilter;
            DGSedistaEkonomskeKlase.ItemsSource = view1;
            DGSedistaEkonomskeKlase.IsSynchronizedWithCurrentItem = true;
            DGSedistaEkonomskeKlase.ColumnWidth = new DataGridLength(1, DataGridLengthUnitType.Star);
            DGSedistaBiznisKlase.ItemsSource = view2;
            DGSedistaBiznisKlase.IsSynchronizedWithCurrentItem = true;
            DGSedistaBiznisKlase.ColumnWidth = new DataGridLength(1, DataGridLengthUnitType.Star);
        }
        private void BtnSacuvaj_Click(Object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
            if(opcija.Equals(Opcija.DODAVANJE) && !PostojiAvion(avion.BrojLeta))
            {
                avion.Sacuvaj();
            }
        }
        private void BtnObrisi_Click(Object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }
        private bool PostojiAvion(String brojLeta)
        {
            foreach(Avion avion in Aplikacija.Instance.Avioni)
            {
                if(avion.BrojLeta.Equals(brojLeta))
                {
                    return true;
                }
            }
            return false;
        }

        private void BtnOdustani_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }
    }
}
