﻿using ProjekatWPF.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProjekatWPF
{
    /// <summary>
    /// Interaction logic for EditAerodrom.xaml
    /// </summary>
    public partial class EditAerodrom : Window
    {
        public enum Opcija { DODAVANJE, IZMENA };
        private Aerodrom aerodrom;
        private Opcija opcija;
        public EditAerodrom(Aerodrom aerodrom, Opcija opcija)
        {
            InitializeComponent();
            this.aerodrom = aerodrom;
            this.opcija = opcija;

            this.DataContext = aerodrom;

            if (opcija.Equals(Opcija.IZMENA))
            {
                TxtSifra.IsEnabled = false;
            }
        }

        private void BtnSacuvaj_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
            if(opcija.Equals(Opcija.DODAVANJE) && !PostojiAerodrom(aerodrom.Sifra))
            {
                aerodrom.Sacuvaj();
            }
        }

        private void BtnOdustani_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }

        private bool PostojiAerodrom(String sifra)
        {
            foreach(Aerodrom aerodrom in Aplikacija.Instance.Aerodromi)
            {
                if(aerodrom.Sifra.Equals(sifra))
                {
                    return true;
                }
            }
            return false;
        }
    }
}
