﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjekatWPF.Model
{
    public class Sediste : INotifyPropertyChanged, ICloneable
    {
        public int Id{ get; set; }

        private String brojSedista;

        public String BrojSedista
        {
            get { return brojSedista; }
            set { brojSedista = value; OnPropertyChanged("Broj sedista"); }
        }

        private bool active;

        public bool Active
        {
            get { return active; }
            set { active = value; OnPropertyChanged("Active"); }
        }


        public event PropertyChangedEventHandler PropertyChanged;

        

        public override string ToString()
        {
            return $"BrojSedista {brojSedista}";
        }
        private void OnPropertyChanged(String name)
        { 
            if(PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(name));
            }
        }
        public object Clone()
        {
            Sediste sediste = new Sediste
            {
                Id = this.Id,
                BrojSedista = this.BrojSedista,
                Active = this.Active
            };
            return sediste;
        }
        public void Sacuvaj()
        {
            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = Aplikacija.CONNECTION_STRING;
                conn.Open();
                SqlCommand command = conn.CreateCommand();
                command.CommandText = @"INSERT INTO Sedista(Id, Broj_sedista, Active)" + "VALUES(@Id,@Broj_sedista,@Active)";
                command.Parameters.Add(new SqlParameter(@"Id", this.Id));
                command.Parameters.Add(new SqlParameter(@"Broj_sedista", this.BrojSedista));
                command.Parameters.Add(new SqlParameter(@"Active", 1));
                command.ExecuteNonQuery();

                // conn.Close();
            }
            Aplikacija.Instance.UcitajSedistaDS();
        }
        public void Izmena()
        {
            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = Aplikacija.CONNECTION_STRING;
                conn.Open();
                SqlCommand command = conn.CreateCommand();
                command.CommandText = @"UPDATE Sedista SET Broj_sedista=@Broj_sedista, Active=@Active Where Id=@Id";
                command.Parameters.Add(new SqlParameter(@"Id", this.Id));
                command.Parameters.Add(new SqlParameter(@"Broj_sedista", this.BrojSedista));
                command.Parameters.Add(new SqlParameter(@"Active", this.Active));
                command.ExecuteNonQuery();

                // conn.Close();
            }
        }
    }
}
