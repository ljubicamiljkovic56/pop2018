﻿using ProjekatWPF.Model;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProjekatWPF
{
    /// <summary>
    /// Interaction logic for PregledLetova.xaml
    /// </summary>
    public partial class PregledLetova : Window
    {
        ICollectionView view1;
        public PregledLetova()
        {
            InitializeComponent();
            view1 = CollectionViewSource.GetDefaultView(Aplikacija.Instance.Letovi);
            DGLetovi.ItemsSource = view1;
            DGLetovi.IsSynchronizedWithCurrentItem = true;
            DGLetovi.ColumnWidth = new DataGridLength(1, DataGridLengthUnitType.Star);
        }
        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            LoginWindow loginWindow = new LoginWindow();
            loginWindow.Show();
        }
        private void BtnKupi_Click(object sender, RoutedEventArgs e)
        {
            NeprijavljeniKupi neprijavljeniKupi = new NeprijavljeniKupi();
            neprijavljeniKupi.ShowDialog();
        }

      
    }
}
