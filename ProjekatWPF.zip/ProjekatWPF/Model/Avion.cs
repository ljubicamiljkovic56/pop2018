﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjekatWPF.Model
{
    public class Avion : INotifyPropertyChanged, ICloneable
    {
        public int Id { get; set; }
        private String brojLeta;

        public String BrojLeta
        {
            get { return brojLeta; }
            set { brojLeta = value; OnPropertyChanged("BrojLeta"); }
        }

        private String  nazivAviokompanije;

        public String  NazivAviokompanije
        {
            get { return nazivAviokompanije; }
            set { nazivAviokompanije = value; OnPropertyChanged("NazivAviokompanije"); }
        }
 


        private bool active;

        public event PropertyChangedEventHandler PropertyChanged;

        public bool Active
        {
            get { return active; }
            set { active = value; OnPropertyChanged("Active"); }
        }

        public override string ToString()
        {
            return $"BrojLeta {BrojLeta},  Naziv Aviokompanije {NazivAviokompanije}";
        }
        private void OnPropertyChanged(String name)
        {
            if(PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(name));
            }
        }

        public object Clone()
        {
            Avion avion = new Avion
            {
                Id = this.Id,
                BrojLeta = this.BrojLeta,
                NazivAviokompanije = this.NazivAviokompanije,
                Active = this.Active
            };
            return avion;
        }
     
        public void Sacuvaj()
        {
            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = Aplikacija.CONNECTION_STRING;
                conn.Open();
                SqlCommand command = conn.CreateCommand();
                command.CommandText = @"INSERT INTO AVIONI(Broj_leta, Naziv_aviokompanije, Active)" + "VALUES(@Broj_leta,@Naziv_aviokompanije,@Active)";
                command.Parameters.Add(new SqlParameter(@"Broj_leta", this.BrojLeta));
                command.Parameters.Add(new SqlParameter(@"Naziv_aviokompanije", this.NazivAviokompanije));
                command.Parameters.Add(new SqlParameter(@"Active", 1));
                command.ExecuteNonQuery();

                // conn.Close();
            }
            Aplikacija.Instance.UcitajAerodromeDS();
        }
        public void Izmena()
        {
            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = Aplikacija.CONNECTION_STRING;
                conn.Open();
                SqlCommand command = conn.CreateCommand();
                command.CommandText = @"UPDATE AVIONI SET Broj_leta=@Broj_leta, Naziv_aviokompanije=@Naziv_aviokompanije, Active=@Active Where Id=@Id";
                command.Parameters.Add(new SqlParameter(@"Id", this.Id));
                command.Parameters.Add(new SqlParameter(@"Broj_leta", this.BrojLeta));
                command.Parameters.Add(new SqlParameter(@"Naziv_aviokompanije", this.NazivAviokompanije));
                command.Parameters.Add(new SqlParameter(@"Active", this.Active));
                command.ExecuteNonQuery();

                // conn.Close();
            }
        }
    }
}
