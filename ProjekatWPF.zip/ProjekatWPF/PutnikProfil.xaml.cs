﻿using ProjekatWPF.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProjekatWPF
{
    /// <summary>
    /// Interaction logic for PutnikProfil.xaml
    /// </summary>
    public partial class PutnikProfil : Window
    {
        ICollectionView view2;
        public PutnikProfil()
        {
            InitializeComponent();
            view2 = CollectionViewSource.GetDefaultView(Aplikacija.Instance.Korisnici);
            DGPutnikProfil.ItemsSource = view2;
            DGPutnikProfil.IsSynchronizedWithCurrentItem = true;
            DGPutnikProfil.ColumnWidth = new DataGridLength(1, DataGridLengthUnitType.Star);
        }
        private void BtnNazad_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }
        private void BtnIzmeniProfil_Click(object sender, RoutedEventArgs e)
        {
            PutnikIzmeniProfil putnikIzmeniProfil = new PutnikIzmeniProfil(Aplikacija.Instance.UlogovanKorisnik);
            putnikIzmeniProfil.ShowDialog();
        }
    }
}
