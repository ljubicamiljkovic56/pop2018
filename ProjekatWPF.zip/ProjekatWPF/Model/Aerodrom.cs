﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjekatWPF.Model
{
    public class Aerodrom : INotifyPropertyChanged, ICloneable
    {
        public int Id { get; set; }
        private string sifra;

        public string Sifra
        {
            get { return sifra; }
            set { sifra = value; OnPropertyChanged("Sifra"); }
        }
        private String naziv;

        public  String Naziv
        {
            get { return naziv; }
            set { naziv = value; OnPropertyChanged("Naziv"); }
        }
        private String grad;

        public  String Grad
        {
            get { return grad; }
            set { grad = value; OnPropertyChanged("Grad"); }
        }
        private bool active;

        public bool Active 
        {
            get { return active; }
            set { active = value; OnPropertyChanged("Active"); }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        public override string ToString()
        {
            return $"Sifra {Sifra}, Naziv {Naziv}, Grad {Grad}";
        }
        private void OnPropertyChanged(String name)
        {
            if(PropertyChanged != null)
            { 
                PropertyChanged(this, new PropertyChangedEventArgs(name));
            }
        }

        public object Clone()
        {
            Aerodrom aerodrom = new Aerodrom
            {
                Id = this.Id,
                Sifra = this.Sifra,
                Naziv = this.Naziv,
                Grad = this.Grad,
                Active = this.Active
            };
            return aerodrom;
        }
        public void Sacuvaj()
        {

            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = Aplikacija.CONNECTION_STRING;
                conn.Open();
                SqlCommand command = conn.CreateCommand();
                command.CommandText = @"INSERT INTO AERODROMI(Naziv, Grad, Sifra, Active)" + "VALUES(@Naziv,@Grad,@Sifra,@Active)";
                command.Parameters.Add(new SqlParameter(@"Naziv", this.Naziv));
                command.Parameters.Add(new SqlParameter(@"Grad", this.Grad));
                command.Parameters.Add(new SqlParameter(@"Sifra", this.Sifra));
                command.Parameters.Add(new SqlParameter(@"Active", 1));
                command.ExecuteNonQuery();

                // conn.Close();
            }
            Aplikacija.Instance.UcitajAerodromeDS();
        }
        public void Izmena()
        {
            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = Aplikacija.CONNECTION_STRING;
                conn.Open();
                SqlCommand command = conn.CreateCommand();
                command.CommandText = @"UPDATE AERODROMI SET Naziv=@Naziv, Grad=@Grad, Sifra=@Sifra, Active=@Active Where Id=@Id";
                command.Parameters.Add(new SqlParameter(@"Id", this.Id));
                command.Parameters.Add(new SqlParameter(@"Naziv", this.Naziv));
                command.Parameters.Add(new SqlParameter(@"Grad", this.Grad));
                command.Parameters.Add(new SqlParameter(@"Sifra", this.Sifra));
                command.Parameters.Add(new SqlParameter(@"Active", this.Active));
                command.ExecuteNonQuery();

                // conn.Close();
            }
            
        }
    }
}
