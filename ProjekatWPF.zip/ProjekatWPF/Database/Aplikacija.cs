﻿using ProjekatWPF.Enumeracije;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace ProjekatWPF.Model
{
    class Aplikacija
    {
        public ObservableCollection<Korisnik> Korisnici { get; set; }
        public Korisnik UlogovanKorisnik { get; set; }
        public Karta KupljenaKarta { get; set; }
        public ObservableCollection<Aerodrom> Aerodromi { get; set; }
        public ObservableCollection<Aviokompanija> Aviokompanije { get; set; }
        public ObservableCollection<Avion> Avioni { get; set; }
        public ObservableCollection<Let> Letovi { get; set; }
        public ObservableCollection<Karta> Karte { get; set; }
        public ObservableCollection<Sediste> Sedista { get; set; }
        public ObservableCollection<Sediste> SedistaEkonomskeKlase { get; set; }
        public ObservableCollection<Sediste> SedistaBiznisKlase { get; set; }
        public List<EPol> PolLista = new List<EPol> { EPol.MUSKI, EPol.ZENSKI };
        public List<ETipKorisnika> TipLista = new List<ETipKorisnika> { ETipKorisnika.ADMINISTRATOR, ETipKorisnika.PUTNIK, ETipKorisnika.NEREGISTROVAN };
       // public String UlogovanKorisnik { get; set; }
        private Let let1;
        private Let let2;
        private Let let3;
        private Sediste sediste1;
        private Sediste sediste2;
        private Sediste sediste3;
        private Sediste sdek1;
        private Sediste sdek2;
        private Sediste sdek3;
        private Sediste sdbk1;
        private Sediste sdbk2;
        private Sediste sdbk3;
        public const String CONNECTION_STRING = @"Data Source=(localdb)\ProjectsV13;Initial Catalog=AvioServis;Integrated Security=true";

        private static Aplikacija instance = null;
    
        

        private Aplikacija()
        {
            this.UlogovanKorisnik = new Korisnik();
            this.KupljenaKarta = new Karta();
            this.Korisnici = new ObservableCollection<Korisnik>();
            this.Aerodromi = new ObservableCollection<Aerodrom>();
            this.Aviokompanije = new ObservableCollection<Aviokompanija>();
            this.Avioni = new ObservableCollection<Avion>();
            this.Letovi = new ObservableCollection<Let>();
            this.Karte = new ObservableCollection<Karta>();
            this.Sedista = new ObservableCollection<Sediste>();
            this.SedistaEkonomskeKlase = new ObservableCollection<Sediste>();
            this.SedistaBiznisKlase = new ObservableCollection<Sediste>();
            /*UcitajAerodrom();
            UcitajLet();
            UcitajAviokompaniju();
            UcitajKorisnika();
            UcitajAvion();
            UcitajKarte();
            UcitajSediste();
            */
            UcitajSedista();
            UcitajSedistaEkonomskeKlase();
            UcitajSedistaBiznisKlase();
            //UnosUBazu();
            //IspisIzBaze();
           
            UcitajAerodromeDS();
            UcitajAviokompanijeDS();
            UcitajLetoveDS();
            UcitajKorisnikeDS();
            UcitajKarteDS();
            UcitajSedistaDS();
            UcitajAvioneDS();

        }
        public void UcitajAerodromeDS()
        {
            Aerodromi.Clear();
            SqlConnection conn = new SqlConnection();
            try
            {
                conn.ConnectionString = CONNECTION_STRING;
                conn.Open();

                SqlCommand command = conn.CreateCommand();
                command.CommandText = "select * from Aerodromi";
                DataSet dsAerodromi = new DataSet();
                SqlDataAdapter daAerodromi = new SqlDataAdapter();
                daAerodromi.SelectCommand = command;
                daAerodromi.Fill(dsAerodromi, "Aerodromi");

                foreach (DataRow row in dsAerodromi.Tables["Aerodromi"].Rows)
                {
                    Aerodrom aerodrom = new Aerodrom();
                    aerodrom.Id = (int) row["Id"];
                    aerodrom.Naziv = (String)row["Naziv"];
                    aerodrom.Grad = (String)row["Grad"];
                    aerodrom.Sifra = (String)row["Sifra"];
                    aerodrom.Active = (bool)row["Active"];
                    Aerodromi.Add(aerodrom);
                }
            }catch (Exception ex)
            {
                Console.WriteLine($"Exception {ex}");
            }finally
            {
                conn.Close();
            }
        }
        public void UcitajAviokompanijeDS()
        {
            Aviokompanije.Clear();
            SqlConnection conn = new SqlConnection();
            try
            {
                conn.ConnectionString = CONNECTION_STRING;
                conn.Open();

                SqlCommand command = conn.CreateCommand();
                command.CommandText = "SELECT * FROM Aviokompanije";
                DataSet dsAviokompanije = new DataSet();
                SqlDataAdapter daAviokompanije = new SqlDataAdapter();
                daAviokompanije.SelectCommand = command;
                daAviokompanije.Fill(dsAviokompanije, "Aviokompanije");

                foreach (DataRow row in dsAviokompanije.Tables["Aviokompanije"].Rows)
                {
                    Aviokompanija aviokompanija = new Aviokompanija();
                    aviokompanija.Id = (int)row["Id"];
                    aviokompanija.Sifra = (String)row["Sifra"];
                    aviokompanija.Active = (bool)row["Active"];
                    Aviokompanije.Add(aviokompanija);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception {ex}");
            }
            finally
            {
                conn.Close();
            }
        }
        public void UcitajLetoveDS()
        {
            Letovi.Clear();
            SqlConnection conn = new SqlConnection();
            try
            {
                conn.ConnectionString = CONNECTION_STRING;
                conn.Open();

                SqlCommand command = conn.CreateCommand();
                command.CommandText = "SELECT * FROM Letovi";
                DataSet dsLetovi = new DataSet();
                SqlDataAdapter daLetovi = new SqlDataAdapter();
                daLetovi.SelectCommand = command;
                daLetovi.Fill(dsLetovi, "Letovi");

                foreach (DataRow row in dsLetovi.Tables["Letovi"].Rows)
                {
                    Let let = new Let();
                    let.Id = (int)row["Id"];
                    let.BrojLeta = (String)row["Broj_leta"];
                    let.VremePolaska = (DateTime)row["VremePolaska"];
                    let.VremeDolaska = (DateTime)row["VremeDolaska"];
                    let.Odrediste = (String)row["Odrediste"];
                    let.Destinacija = (String)row["Destinacija"];
                    let.CenaLeta = (Double)row["Cena_leta"];
                    let.AviokompanijaId = (int)row["AviokompanijaId"];
                    let.Pilot = (String)row["Pilot"];
                    let.Active = (bool)row["Active"];
                    Letovi.Add(let);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception {ex}");
            }
            finally
            {
                conn.Close();
            }
        }
        public void UcitajKorisnikeDS()
        {
            Korisnici.Clear();
            SqlConnection conn = new SqlConnection();
            try
            {
                conn.ConnectionString = CONNECTION_STRING;
                conn.Open();

                SqlCommand command = conn.CreateCommand();
                command.CommandText = "SELECT * FROM Korisnici";
                DataSet dsKorisnici = new DataSet();
                SqlDataAdapter daKorisnici = new SqlDataAdapter();
                daKorisnici.SelectCommand = command;
                daKorisnici.Fill(dsKorisnici, "Korisnici");

                foreach (DataRow row in dsKorisnici.Tables["Korisnici"].Rows)
                {
                    Korisnik korisnik = new Korisnik();
                    korisnik.Id = (int)row["Id"];
                    korisnik.KorisnickoIme = (String)row["Korisnicko_ime"];
                    korisnik.Lozinka = (String)row["Lozinka"];
                    korisnik.Ime = (String)row["Ime"];
                    korisnik.Prezime = (String)row["Prezime"];
                    korisnik.Pol = (EPol)Enum.Parse(typeof(EPol), (string)row["Pol"], true);
                    korisnik.Email = (String)row["Email"];
                    korisnik.AdresaStanovanja = (String)row["Adresa_stanovanja"];
                    korisnik.TipKorisnika = (ETipKorisnika)Enum.Parse(typeof(ETipKorisnika), (string)row["Tip_korisnika"], true);
                    korisnik.Active = (bool)row["Active"];
                    Korisnici.Add(korisnik);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception {ex}");
            }
            finally
            {
                conn.Close();
            }
        }
        public void UcitajKarteDS()
        {
            Karte.Clear();
            SqlConnection conn = new SqlConnection();
            try
            {
                conn.ConnectionString = CONNECTION_STRING;
                conn.Open();

                SqlCommand command = conn.CreateCommand();
                command.CommandText = "SELECT * FROM Karte";
                DataSet dsKarte = new DataSet();
                SqlDataAdapter daKarte = new SqlDataAdapter();
                daKarte.SelectCommand = command;
                daKarte.Fill(dsKarte, "Karte");

                foreach (DataRow row in dsKarte.Tables["Karte"].Rows)
                {
                    Karta karta = new Karta();
                    karta.Id = (int)row["Id"];
                    karta.BrojLeta = (String)row["Broj_leta"];
                    karta.BrojSedista = (String)row["Broj_sedista"];
                    karta.NazivPutnika = (String)row["Naziv_putnika"];
                    karta.Odrediste = (String)row["Odrediste"];
                    karta.Destinacija = (String)row["Destinacija"];
                    karta.Kapija = (String)row["Kapija"];
                    karta.UkupnaCenaKarte = (Double)row["Ukupna_cena_karte"];
                    karta.Active = (bool)row["Active"];
                    Karte.Add(karta);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception {ex}");
            }
            finally
            {
                conn.Close();
            }
        }
        public void UcitajSedistaDS()
        {
            Sedista.Clear();
            SqlConnection conn = new SqlConnection();
            try
            {
                conn.ConnectionString = CONNECTION_STRING;
                conn.Open();

                SqlCommand command = conn.CreateCommand();
                command.CommandText = "select * from Sedista";
                DataSet dsSedista = new DataSet();
                SqlDataAdapter daSedista = new SqlDataAdapter();
                daSedista.SelectCommand = command;
                daSedista.Fill(dsSedista, "Sedista");

                foreach (DataRow row in dsSedista.Tables["Sedista"].Rows)
                {
                    Sediste sediste = new Sediste();
                    sediste.Id = (int)row["Id"];
                    sediste.BrojSedista = (String)row["Broj_sedista"];
                    sediste.Active = (bool)row["Active"];
                    Sedista.Add(sediste);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception {ex}");
            }
            finally
            {
                conn.Close();
            }
        }
        public void UcitajAvioneDS()
        {
            Avioni.Clear();
            SqlConnection conn = new SqlConnection();
            try
            {
                conn.ConnectionString = CONNECTION_STRING;
                conn.Open();

                SqlCommand command = conn.CreateCommand();
                command.CommandText = "select * from Avioni";
                DataSet dsAvioni = new DataSet();
                SqlDataAdapter daAvioni = new SqlDataAdapter();
                daAvioni.SelectCommand = command;
                daAvioni.Fill(dsAvioni, "Avioni");

                foreach (DataRow row in dsAvioni.Tables["Avioni"].Rows)
                {
                    Avion avion = new Avion();
                    avion.Id = (int)row["Id"];
                    avion.BrojLeta = (String)row["Broj_leta"];
                    avion.NazivAviokompanije= (String)row["Naziv_aviokompanije"];
                    avion.Active = (bool)row["Active"];
                    Avioni.Add(avion);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception {ex}");
            }
            finally
            {
                conn.Close();
            }
        }
        private void IspisIzBaze()
        {
            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = CONNECTION_STRING;
                conn.Open();
                SqlCommand com = conn.CreateCommand();
                com.CommandText = @"SELECT * FROM AERODROMI";
                SqlDataReader read = com.ExecuteReader();
                while (read.Read())
                {
                    Console.Write(read[0] + " " + read[1] + " " + read[2] + " " + read[3] + " " + read[4]);
                }
                read.Close();
            }
        }
        private void UcitajSedista()
        {
            sediste1 = new Sediste
            {
                
                BrojSedista = "11" 
            };
            Sedista.Add(sediste1);
            sediste2 = new Sediste
            {
                
                BrojSedista = "12"
               
            };
            Sedista.Add(sediste2);
            sediste3 = new Sediste
            {
                
                BrojSedista = "13"
            };
            Sedista.Add(sediste3);
        }
        private void UcitajSedistaEkonomskeKlase()
        {
            sdek1 = new Sediste
            {
                Id = 23,
                BrojSedista ="23"
            };
            SedistaEkonomskeKlase.Add(sdek1);
            sdek2 = new Sediste
            {
                Id = 24,
                BrojSedista = "24"
            };
            SedistaEkonomskeKlase.Add(sdek2);
            sdek3 = new Sediste
            {
                Id = 25,
                BrojSedista ="25"
            };
            SedistaEkonomskeKlase.Add(sdek3);
        }
        
        private void UcitajSedistaBiznisKlase()
        {
            sdbk1 = new Sediste
            {
                Id = 13,
                BrojSedista = "13"
            };
            SedistaBiznisKlase.Add(sdbk1);
            sdbk2 = new Sediste
            {
                Id = 11,
                BrojSedista ="11"
            };
            SedistaBiznisKlase.Add(sdbk2);
            sdbk3 = new Sediste
            {
                Id = 12,
                BrojSedista = "12"
            };
            SedistaBiznisKlase.Add(sdbk3);
        }
        
        public void UcitajLet()
        {
            let1 = new Let
            {
                Destinacija = "BEG",
                Odrediste = "MIL",
                BrojLeta = "123",
                VremeDolaska = new DateTime(2018, 11, 1, 1, 00, 00),
                VremePolaska = new DateTime(2018, 11, 5, 1, 00, 00)
            };
            Letovi.Add(let1);
            let2 = new Let
            {
                Destinacija = "LON",
                Odrediste = "MIL",
                BrojLeta = "124",
                VremeDolaska = new DateTime(2018, 11, 1, 1, 00, 00),
                VremePolaska = new DateTime(2018, 11, 5, 1, 00, 00)
            };
            Letovi.Add(let2);
            let3 = new Let
            {
                Destinacija = "BEG",
                Odrediste = "LON",
                BrojLeta = "125",
                VremeDolaska = new DateTime(2018, 11, 1, 1, 00, 00),
                VremePolaska = new DateTime(2018, 11, 5, 1, 00, 00)
            };
            Letovi.Add(let3);
        }
        public static Aplikacija Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new Aplikacija();
                }
                return instance;
            }
        }



      /*  public void UcitajAerodrom()
        {
            XmlReader reader = XmlReader.Create("..//..//Data//Aerodromi.xml");
            while (reader.Read())
            {
                if (reader.NodeType.Equals(XmlNodeType.Element) && reader.Name.Equals("aerodrom"))
                {
                    String sifra = reader.GetAttribute("sifra");
                    String naziv = reader.GetAttribute("naziv");
                    String grad = reader.GetAttribute("grad");
                    Aerodromi.Add(new Aerodrom
                    {
                        Sifra = sifra,
                        Grad = grad,
                        Naziv = naziv,
                        Active = true

                    });
                }
            }
            reader.Close();

        }
        */
        public void SacuvajAerodrom()
        {
            XmlWriter writer = XmlWriter.Create("..//..//Data//Aerodromi.xml");

            writer.WriteStartElement("aerodromi");

            foreach (var aerodrom in Aerodromi)
            {
                writer.WriteStartElement("aerodrom");
                writer.WriteAttributeString("sifra", aerodrom.Sifra);
                writer.WriteAttributeString("naziv", aerodrom.Naziv);
                writer.WriteAttributeString("grad", aerodrom.Grad);
                writer.WriteEndElement();
            }

            writer.WriteEndDocument();
            writer.Close();
        }
        public void UcitajKorisnika()
        {
            XmlReader reader = XmlReader.Create("..//..//Data//Korisnici.xml");
            while (reader.Read())
            {
                if (reader.NodeType.Equals(XmlNodeType.Element) && reader.Name.Equals("korisnik"))
                {
                    String ime = reader.GetAttribute("ime");
                    String prezime = reader.GetAttribute("prezime");
                    String email = reader.GetAttribute("email");
                    String adresaStanovanja = reader.GetAttribute("adresaStanovanja");
                    //Enumeracije.EPol pol = reader.GetAttribute("pol");
                    String korisnickoIme = reader.GetAttribute("korisnickoIme");
                    String lozinka = reader.GetAttribute("lozinka");
                    //Enumeracije.ETipKorisnika tip = reader.GetAttribute("tip");
                    Korisnici.Add(new Korisnik
                    {
                        Ime = ime,
                        Prezime = prezime,
                        Email = email,
                        AdresaStanovanja = adresaStanovanja,
                        //Pol = pol,
                        KorisnickoIme = korisnickoIme,
                        Lozinka = lozinka,
                        //TipKorisnika = tip,
                        Active = true

                    });
                }
            }
        }

        public void SacuvajKorisnika()
        {
            XmlWriter writer = XmlWriter.Create("..//..//Data//Korisnici.xml");

            writer.WriteStartElement("korisnici");

            foreach (var korisnik in Korisnici)
            {
                writer.WriteStartElement("korisnik");
                writer.WriteAttributeString("ime", korisnik.Ime);
                writer.WriteAttributeString("prezime", korisnik.Prezime);
                writer.WriteAttributeString("email", korisnik.Email);
                writer.WriteAttributeString("adresaStanovanja", korisnik.AdresaStanovanja);
                writer.WriteAttributeString("pol", korisnik.Pol.ToString());
                writer.WriteAttributeString("korisnickoIme", korisnik.KorisnickoIme);
                writer.WriteAttributeString("lozinka", korisnik.Lozinka);
                writer.WriteAttributeString("tip", korisnik.TipKorisnika.ToString());
                writer.WriteEndElement();
            }

            writer.WriteEndDocument();
            writer.Close();
        }

        public void UcitajAviokompaniju()
        {
            XmlReader reader = XmlReader.Create("..//..//Data//Aviokompanije.xml");
            while (reader.Read())
            {
                if (reader.NodeType.Equals(XmlNodeType.Element) && reader.Name.Equals("aviokompanija"))
                {
                    String sifra = reader.GetAttribute("sifra");
                    Aviokompanije.Add(new Aviokompanija
                    {
                        Sifra = sifra,
                        //Letovi = new ObservableCollection<Let>() {let1, let2, let3 },
                        Active = true
                    });

                }
            }
        }
        
        public void SacuvajAviokompaniju()
        {
            XmlWriter writer = XmlWriter.Create("..//..//Data//Aviokompanije.xml");

            writer.WriteStartElement("aviokompanije");
            foreach (var aviokompanija in Aviokompanije)
            {
                writer.WriteStartElement("aviokompanija");
                writer.WriteAttributeString("sifra", aviokompanija.Sifra);
                writer.WriteEndElement();
            }
            writer.WriteEndDocument();
            writer.Close();
        }

        public void UcitajAvion()
        {
            XmlReader reader = XmlReader.Create("..//..//Data//Avioni.xml");
            while (reader.Read())
            {
                if (reader.NodeType.Equals(XmlNodeType.Element) && reader.Name.Equals("avion"))
                {
                    String pilot = reader.GetAttribute("pilot");
                    String brojLeta = reader.GetAttribute("brojLeta");
                    String nazivAviokompanije = reader.GetAttribute("nazivAviokompanije");
                    Avioni.Add(new Avion
                    {
                        BrojLeta = brojLeta,
                        NazivAviokompanije = nazivAviokompanije,
                        Active = true
                    });

                }
            }
        }
        public void SacuvajAvion()
        {
            XmlWriter writer = XmlWriter.Create("..//..//Data//Avioni.xml");

            writer.WriteStartElement("avioni");
            foreach (var avion in Avioni)
            {
                writer.WriteStartElement("avion");
                writer.WriteAttributeString("brojLeta", avion.BrojLeta);
                writer.WriteAttributeString("nazivAviokompanije", avion.NazivAviokompanije);
                writer.WriteEndElement();
            }
            writer.WriteEndDocument();
            writer.Close();
        }
        public void UcitajLetove()
        {
            XmlReader reader = XmlReader.Create("..//..//Data//Letovi.xml");
            while (reader.Read())
            {
                if (reader.NodeType.Equals(XmlNodeType.Element) && reader.Name.Equals("let"))
                {
                    String brojLeta = reader.GetAttribute("brojLeta");
                    String odrediste = reader.GetAttribute("odrediste");
                    String destinacija = reader.GetAttribute("destinacija");
                    Double cenaLeta = Double.Parse(reader.GetAttribute("cenaLeta"));
                    int aviokompanijaId = int.Parse(reader.GetAttribute("aviokompanijaId"));
                    String pilot = reader.GetAttribute(reader.GetAttribute("pilot"));
                    Letovi.Add(new Let
                    {
                        BrojLeta = brojLeta,
                        Odrediste = odrediste,
                        Destinacija = destinacija,
                        CenaLeta = cenaLeta,
                        AviokompanijaId = aviokompanijaId,
                        Pilot = pilot,
                        Active = true
                    });

                }
            }
        }

        public void SacuvajLetove()
        {
            XmlWriter writer = XmlWriter.Create("..//..//Data//Letovi.xml");

            writer.WriteStartElement("letovi");
            foreach (var let in Letovi)
            {
                writer.WriteStartElement("let");
                writer.WriteAttributeString("brojLeta", let.BrojLeta);
                writer.WriteAttributeString("odrediste", let.Odrediste);
                writer.WriteAttributeString("destinacija", let.Destinacija);
                writer.WriteAttributeString("cenaLeta", let.CenaLeta.ToString());
                writer.WriteAttributeString("aviokompanijaId", let.AviokompanijaId.ToString());
                writer.WriteAttributeString("pilot", let.Pilot);
                writer.WriteEndElement();
            }
            writer.WriteEndDocument();
            writer.Close();
        }
        public void UcitajKarte()
        {
            XmlReader reader = XmlReader.Create("..//..//Data//Karte.xml");
            while (reader.Read())
            {
                if (reader.NodeType.Equals(XmlNodeType.Element) && reader.Name.Equals("karta"))
                {
                    String brojLeta = reader.GetAttribute("brojLeta");
                    String brojSedista = reader.GetAttribute("brojSedista");
                    String nazivPutnika = reader.GetAttribute("nazivPutnika");
                    String odrediste = reader.GetAttribute("odrediste");
                    String destinacija = reader.GetAttribute("destinacija");
                    String kapija = reader.GetAttribute("kapija");
                    Double ukupnaCenaKarte = Double.Parse(reader.GetAttribute("ukupnaCenaKarte"));
                    Karte.Add(new Karta
                    {
                        BrojLeta = brojLeta,
                        BrojSedista = brojSedista,
                        NazivPutnika = nazivPutnika,
                        Odrediste = odrediste,
                        Destinacija = destinacija,
                        Kapija = kapija,
                        UkupnaCenaKarte = ukupnaCenaKarte,
                        Active = true
                    });

                }
            }
        }
        public void SacuvajKarte()
        {
            XmlWriter writer = XmlWriter.Create("..//..//Data//Karte.xml");

            writer.WriteStartElement("karte");
            foreach (var karta in Karte)
            {
                writer.WriteStartElement("karta");
                writer.WriteAttributeString("brojLeta", karta.BrojLeta);
                writer.WriteAttributeString("brojSedista", karta.BrojSedista);
                writer.WriteAttributeString("nazivPutnika", karta.NazivPutnika);
                writer.WriteAttributeString("odrediste", karta.Odrediste);
                writer.WriteAttributeString("destinacija", karta.Destinacija);
                writer.WriteAttributeString("kapija", karta.Kapija);
                writer.WriteAttributeString("ukupnaCenaKarte", karta.UkupnaCenaKarte.ToString());
                writer.WriteEndElement();
            }
            writer.WriteEndDocument();
            writer.Close();
        }
        public void UcitajSediste()
        {
            XmlReader reader = XmlReader.Create("..//..//Data//Sediste.xml");
            while (reader.Read())
            {
                if (reader.NodeType.Equals(XmlNodeType.Element) && reader.Name.Equals("sediste"))
                {
                    String Id = reader.GetAttribute("BrojSedista");
                    Sedista.Add(new Sediste
                    {
                       
                    });
                }
            }

        }
        public void SacuvajSediste()
        {
            XmlWriter writer = XmlWriter.Create("..//..//Data//Sediste.xml");

            writer.WriteStartElement("sediste");
            foreach (var sediste in Sedista)
            {
                writer.WriteStartElement("sediste");
                writer.WriteAttributeString("brojSedista", sediste.BrojSedista);
                writer.WriteEndElement();
            }
            writer.WriteEndDocument();
            writer.Close();
        }
    }
}