﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjekatWPF.Model
{
    public class Let : INotifyPropertyChanged, ICloneable

    {
        public int Id { get; set; }
        public int AviokompanijaId { get; set; }
        private String brojLeta;

        public String BrojLeta 
        {
            get { return brojLeta; }
            set { brojLeta = value; OnPropertyChanged("Broj leta");  }
        }
        private String odrediste ;

        public String Odrediste
        {
            get { return odrediste; }
            set { odrediste = value; OnPropertyChanged("Odrediste"); }
        }

        private String destinacija;

        public String Destinacija
        {
            get { return destinacija; }
            set { destinacija = value; OnPropertyChanged("Destinacija"); }
        }
        private DateTime vremeDolaska;

        public DateTime VremeDolaska
        {
            get { return vremeDolaska; }
            set { vremeDolaska = value; OnPropertyChanged("Vreme dolaska"); }
        }
        private DateTime vremePolaska;

        public DateTime VremePolaska
        {
            get { return vremePolaska; }
            set { vremePolaska = value; OnPropertyChanged("Vreme polaska"); }
        }


        private Double cenaLeta;

        public Double CenaLeta
        {
            get { return cenaLeta; }
            set { cenaLeta = value; OnPropertyChanged("Cena leta"); }
        }
        public String Pilot
        {
            get { return pilot; }
            set { pilot = value; OnPropertyChanged("Pilot"); }
        }
        private string pilot;
        private bool active;
       

        public bool Active
        {
            get { return active; }
            set { active = value; OnPropertyChanged("Active"); }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        public override string ToString()
        {
            return $"BrojLeta {BrojLeta}, Odrediste {Odrediste}, Destinacija {Destinacija}, VremeDolaska {VremeDolaska}, VremePolaska{VremePolaska}, Pilot {Pilot}";
        }

        private void OnPropertyChanged(String name)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(name));
            }
        }

        public object Clone()
        {
           Let let = new Let
           {
               Id = this.Id,
               BrojLeta = this.BrojLeta,
               Destinacija = this.Destinacija,
               Odrediste = this.odrediste,
               VremeDolaska = this.VremeDolaska,
               VremePolaska = this.VremePolaska,
               CenaLeta = this.cenaLeta,
               AviokompanijaId = this.AviokompanijaId,
               Pilot = this.Pilot,
               Active = this.active
           };
           return let;
        }
        public void Sacuvaj()
        {

            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = Aplikacija.CONNECTION_STRING;
                conn.Open();
                SqlCommand command = conn.CreateCommand();
                command.CommandText = @"INSERT INTO LETOVI(Broj_leta,VremePolaska,VremeDolaska,Odrediste,Destinacija,Cena_leta,AviokompanijaId,Pilot,Active)" + 
                    "VALUES(@Broj_leta,@VremePolaska,@VremeDolaska,@Odrediste,@Destinacija,@Cena_leta,@AviokompanijaId,@Pilot,@Active)";
                command.Parameters.Add(new SqlParameter(@"Broj_leta", this.BrojLeta));
                command.Parameters.Add(new SqlParameter(@"VremePolaska", this.VremePolaska));
                command.Parameters.Add(new SqlParameter(@"VremeDolaska", this.VremeDolaska));
                command.Parameters.Add(new SqlParameter(@"Odrediste", this.Odrediste));
                command.Parameters.Add(new SqlParameter(@"Destinacija", this.Destinacija));
                command.Parameters.Add(new SqlParameter(@"Cena_leta", this.CenaLeta));
                command.Parameters.Add(new SqlParameter(@"AviokompanijaId", this.AviokompanijaId));
                command.Parameters.Add(new SqlParameter(@"Pilot", this.Pilot));
                command.Parameters.Add(new SqlParameter(@"Active", 1));
                command.ExecuteNonQuery();

                // conn.Close();
            }
            Aplikacija.Instance.UcitajLetoveDS();
        }
        public void Izmena()
        {
            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = Aplikacija.CONNECTION_STRING;
                conn.Open();
                SqlCommand command = conn.CreateCommand();
                command.CommandText = @"UPDATE LETOVI SET Broj_leta=@Broj_leta,VremePolaska=@VremePolaska,VremeDolaska=@VremeDolaska,Odrediste=@Odrediste,Destinacija=@Destinacija,Cena_leta=@Cena_leta,AviokompanijaId=@AviokompanijaId,Pilot=@Pilot,Active=@Active Where Id=@Id";
                command.Parameters.Add(new SqlParameter(@"Id", this.Id));
                command.Parameters.Add(new SqlParameter(@"Broj_leta", this.BrojLeta));
                command.Parameters.Add(new SqlParameter(@"VremePolaska", this.VremePolaska));
                command.Parameters.Add(new SqlParameter(@"VremeDolaska", this.VremeDolaska));
                command.Parameters.Add(new SqlParameter(@"Odrediste", this.Odrediste));
                command.Parameters.Add(new SqlParameter(@"Destinacija", this.Destinacija));
                command.Parameters.Add(new SqlParameter(@"Cena_leta", this.CenaLeta));
                command.Parameters.Add(new SqlParameter(@"AviokompanijaId", this.AviokompanijaId));
                command.Parameters.Add(new SqlParameter(@"Pilot", this.Pilot));
                command.Parameters.Add(new SqlParameter(@"Active", this.Active));
                command.ExecuteNonQuery();

                // conn.Close();
            }
        }
    }
}
