﻿using ProjekatWPF.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProjekatWPF
{
    /// <summary>
    /// Interaction logic for PutnikWindow.xaml
    /// </summary>
    public partial class PutnikWindow : Window
    {
        public PutnikWindow()
        {
            InitializeComponent();
        }
        private void BtnLetovi_Click(object sender, RoutedEventArgs e)
        {
            PutnikLetovi putnikLetovi = new PutnikLetovi();
            putnikLetovi.ShowDialog();
        }
        private void BtnKupljeneKarte_Click(object sender, RoutedEventArgs e)
        {
            PutnikKarte putnikKarte = new PutnikKarte();
            putnikKarte.ShowDialog();
        }
        private void BtnPregledProfila_Click(object sender, RoutedEventArgs e)
        {
            PutnikProfil putnikProfil = new PutnikProfil();
            putnikProfil.ShowDialog();
        }
        private void BtnKupiKartu_Click(object sender, RoutedEventArgs e)
        {
            PutnikKupiKartu putnikKupiKartu = new PutnikKupiKartu(Aplikacija.Instance.KupljenaKarta);
            putnikKupiKartu.ShowDialog();
        }
        private void BtnLogout_Click(object sender, RoutedEventArgs e)
        {
            var login = new LoginWindow();
            login.Show();
            this.Close();
        }
        private void BtnSedista_Click(object sender, RoutedEventArgs e)
        {
            PregledSedista pregledSedista = new PregledSedista();
            pregledSedista.ShowDialog();
        }
    }
}
