﻿using ProjekatWPF.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ProjekatWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnAerodromi_Click(object sender, RoutedEventArgs e)
        {
            AerodromiWindow aerodromiWindow = new AerodromiWindow();
            aerodromiWindow.Show();
        }
        private void BtnLetovi_Click(object sender, RoutedEventArgs e)
        {
            LetoviWindow letoviWindow = new LetoviWindow();
            letoviWindow.Show();
        }
        private void BtnAviokompanije_Click(Object sender, RoutedEventArgs e)
        {
            AviokompanijeWindow aviokompanijeWindow = new AviokompanijeWindow();
            aviokompanijeWindow.Show();
        }
        private void BtnKorisnici_Click(Object sender, RoutedEventArgs e)
        {
            KorisniciWindow korisniciWindow = new KorisniciWindow();
            korisniciWindow.Show();
        }
        private void BtnAvioni_Click(Object sender, RoutedEventArgs e)
        {
            AvioniWindow avioniWindow = new AvioniWindow();
            avioniWindow.Show();
        }
        private void BtnKarte_Click(Object sender, RoutedEventArgs e)
        {
            KartaWindow kartaWindow = new KartaWindow();
            kartaWindow.Show();
        }
        private void BtnSediste_Click(Object sender, RoutedEventArgs e)
        {
            SedisteWindow sedisteWindow = new SedisteWindow();
            sedisteWindow.Show();
        }
        private void BtnSedista_Click(Object sender, RoutedEventArgs e)
        {
            SedistaWindow sedistaWindow = new SedistaWindow();
            sedistaWindow.Show();
        }
    }
}
