﻿using ProjekatWPF.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProjekatWPF
{
    /// <summary>
    /// Interaction logic for SedistaWindow.xaml
    /// </summary>
    public partial class SedistaWindow : Window
    {
        ICollectionView view1;
        ICollectionView view2;
        
        public SedistaWindow()
        {
            InitializeComponent();
            view1 = CollectionViewSource.GetDefaultView(Aplikacija.Instance.Sedista);
            view2 = CollectionViewSource.GetDefaultView(Aplikacija.Instance.SedistaBiznisKlase);
            DGSlobodnaSedista.ItemsSource = view1;
            DGSlobodnaSedista.IsSynchronizedWithCurrentItem = true;
            DGSlobodnaSedista.ColumnWidth = new DataGridLength(1, DataGridLengthUnitType.Star);
            DGZauzetaSedista.ItemsSource = view2;
            DGZauzetaSedista.IsSynchronizedWithCurrentItem = true;
            DGZauzetaSedista.ColumnWidth = new DataGridLength(1, DataGridLengthUnitType.Star);



        }
       
    }
}
