﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjekatWPF.Model
{
    public class Aviokompanija : INotifyPropertyChanged, ICloneable
    {
        public int Id { get; set; }
        private String sifra;

        public String Sifra
        {
            get { return sifra; }
            set { sifra = value; OnPropertyChanged("Sifra"); }
        }

        private bool active;

        public bool Active
        {
            get { return active; }
            set { active = value; OnPropertyChanged("Active"); }
        }
        public List<int> Letovi { get; set; }

        public event PropertyChangedEventHandler PropertyChanged;

        public override string ToString()
        {
            return $"Sifra {Sifra}, Letovi {Letovi}";
        }

        private void OnPropertyChanged(String name)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(name));
            }
        }
        public object Clone()
        {
            Aviokompanija aviokompanija = new Aviokompanija
            {
                Id = this.Id,
                Sifra = this.Sifra,
                Letovi = this.Letovi,
                Active = this.Active

            };
            return aviokompanija;
        }
        public void Sacuvaj()
        {

            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = Aplikacija.CONNECTION_STRING;
                conn.Open();
                SqlCommand command = conn.CreateCommand();
                command.CommandText = @"INSERT INTO AVIOKOMPANIJE(Sifra, Active)" + "VALUES(@Sifra,@Active)";
                command.Parameters.Add(new SqlParameter(@"Sifra", this.Sifra));
                command.Parameters.Add(new SqlParameter(@"Active", 1));
                command.ExecuteNonQuery();

                // conn.Close();
            }
            Aplikacija.Instance.UcitajAviokompanijeDS();
        }

        public void Izmena()
        {
            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = Aplikacija.CONNECTION_STRING;
                conn.Open();
                SqlCommand command = conn.CreateCommand();
                command.CommandText = @"UPDATE AVIOKOMPANIJE SET Sifra=@Sifra, Active=@Active Where Id=@Id";
                command.Parameters.Add(new SqlParameter(@"Id", this.Id));
                command.Parameters.Add(new SqlParameter(@"Sifra", this.Sifra));
                command.Parameters.Add(new SqlParameter(@"Active", this.Active));
                command.ExecuteNonQuery();

                // conn.Close();
            }
        }

    }
}
