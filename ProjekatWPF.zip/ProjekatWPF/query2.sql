﻿insert into Aviokompanije (Sifra, Active) VALUES ('AVIO1',1)
select * From Aviokompanije

insert into Letovi (Broj_leta,VremePolaska,VremeDolaska,Odrediste,Destinacija,Cena_leta,AviokompanijaId,Active)
			VALUES ('01',GETDATE(),GETDATE(),'a','a',1,2,1)

select * From Letovi
/* popraviti tu tabelu*/
select * From Aerodromi
CREATE TABLE [dbo].[Aerodromi] (
    [Id]      INT          IDENTITY (1, 1) NOT NULL,
    [Naziv]   VARCHAR (50) NOT NULL,
    [Grad]    VARCHAR (50) NOT NULL,
    [Sifra]   VARCHAR (50) NOT NULL,
    [Active] BIT          NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);
insert into Aerodromi (Naziv,Grad,Sifra,Active) VALUES ('a','a',1,1)