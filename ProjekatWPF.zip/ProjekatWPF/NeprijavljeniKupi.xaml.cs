﻿using ProjekatWPF.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProjekatWPF
{
    /// <summary>
    /// Interaction logic for NeprijavljeniKupi.xaml
    /// </summary>
    public partial class NeprijavljeniKupi : Window
    {
        ICollectionView view;
        public NeprijavljeniKupi()
        {
            InitializeComponent();
            view = CollectionViewSource.GetDefaultView(Aplikacija.Instance.Karte);
            DGKarte.ItemsSource = view;
            DGKarte.IsSynchronizedWithCurrentItem = true;
            DGKarte.ColumnWidth = new DataGridLength(1, DataGridLengthUnitType.Star);

        }
        private void BtnKupi_Click(object sender, RoutedEventArgs e)
        {
            EditKarte editKarte = new EditKarte(new Karta(), EditKarte.Opcija.DODAVANJE);
            editKarte.ShowDialog();
        }
        private void BtnNazad_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }
    }
}
