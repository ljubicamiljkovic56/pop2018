﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjekatWPF.Model
{
    public class Sedista : INotifyPropertyChanged, ICloneable
    {
        private String idSedista;

        public String IdSedista 
        {
            get { return idSedista; }
            set { idSedista = value; OnPropertyChanged("IdSedista"); }
        }
        private List<Sediste> slobodnaSedista;

        public List<Sediste> SlobodnaSedista
        {
            get { return slobodnaSedista; }
            set { slobodnaSedista = value; OnPropertyChanged("SlobodnaSedista"); }
        }

        private List<Sediste> zauzetaSedista;

        public event PropertyChangedEventHandler PropertyChanged;

        public List<Sediste> ZauzetaSedista
        {
            get { return zauzetaSedista; }
            set { zauzetaSedista = value; OnPropertyChanged("ZauzetaSedista"); }
        }
        private bool active;

        public bool Active
        {
            get { return active; }
            set { active = value; OnPropertyChanged("Active"); }
        }

        public override string ToString()
        {
            return $"Id sedista {idSedista}, Slobodna sedista {slobodnaSedista}, Zauzeta sedista {zauzetaSedista}";
        }
        private void OnPropertyChanged(String name)
        {
            if(PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(name));
            }
        }

        public object Clone()
        {
            Sedista sedista = new Sedista
            {
                IdSedista = this.idSedista,
                SlobodnaSedista = this.SlobodnaSedista,
                ZauzetaSedista = this.ZauzetaSedista,
                Active = this.Active
            };
            return sedista;
        }
    }
}
