﻿using ProjekatWPF.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProjekatWPF
{
    /// <summary>
    /// Interaction logic for EditKarte.xaml
    /// </summary>
    public partial class EditKarte : Window
    {
        public enum Opcija { DODAVANJE, IZMENA};
        private Karta karta;
        private Opcija opcija;
        public EditKarte(Karta karta, Opcija opcija)
        {
            InitializeComponent();
            this.karta = karta;
            this.opcija = opcija;

            this.DataContext = karta;

            if(opcija.Equals(Opcija.IZMENA))
            {
                TxtBrojLeta.IsEnabled = false;
            }

        }

        private void BtnSacuvaj_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
            if(opcija.Equals(Opcija.DODAVANJE) && !PostojiKarta(karta.BrojLeta))
            {
                //Aplikacija.Instance.Karte.Add(karta);
                karta.Sacuvaj();
            }
        }
        private void BtnOdustani_Click(Object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }
        private bool PostojiKarta(String brojLeta)
        {
            foreach(Karta karta in Aplikacija.Instance.Karte)
            {
                if(karta.BrojLeta.Equals(brojLeta))
                {
                    return true;
                }
            }
            return false;
        }
    }
}
