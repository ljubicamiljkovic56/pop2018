﻿using ProjekatWPF.Enumeracije;
using ProjekatWPF.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjekatWPF.Model
{
    public class Korisnik : INotifyPropertyChanged, ICloneable
    {
        public int Id { get; set; }

        private String korisnickoIme;

        public String KorisnickoIme
        {
            get { return korisnickoIme; }
            set { korisnickoIme = value; OnPropertyChanged("KorisnickoIme"); }
        }
        private String lozinka;

        public String Lozinka
        {
            get { return lozinka; }
            set { lozinka = value; OnPropertyChanged("Lozinka"); }
        }
        private String ime;

        public String Ime
        {
            get { return ime; }
            set { ime = value; OnPropertyChanged("Ime"); }
        }
        private String prezime;

        public String Prezime
        {
            get { return prezime; }
            set { prezime = value; OnPropertyChanged("Prezime"); }
        }
        private EPol pol;

        public EPol Pol
        {
            get { return pol; }
            set { pol = value; OnPropertyChanged("Pol"); }
        }
        private String email;

        public String Email
        {
            get { return email; }
            set { email = value; OnPropertyChanged("Email"); }
        }
        private String adresaStanovanja;

        public String AdresaStanovanja
        {
            get { return adresaStanovanja; }
            set { adresaStanovanja = value; OnPropertyChanged("AdresaStanovanja"); }
        }
        private ETipKorisnika tipKorisnika;

        public ETipKorisnika TipKorisnika
        {
            get { return tipKorisnika; }
            set { tipKorisnika = value; OnPropertyChanged("TipKorisnika"); }
        }
        private bool active;

        public bool Active
        {
            get { return active; }
            set { active = value; OnPropertyChanged("Active"); }
        }


        public event PropertyChangedEventHandler PropertyChanged;

        public override string ToString()
        {
            return $"Korisnicko ime {KorisnickoIme}, Lozinka {Lozinka}, Ime {Ime}, Prezime {Prezime}, Pol {Pol}, Email {Email}, Adresa {AdresaStanovanja}, Tip korisnika {TipKorisnika}";
        }

        private void OnPropertyChanged(String name)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(name));
            }
        }
        public object Clone()
        {
            Korisnik korisnik = new Korisnik
            {
                Id = this.Id,
                KorisnickoIme = this.KorisnickoIme,
                Lozinka = this.Lozinka,
                Ime = this.Ime,
                Prezime = this.Prezime,
                Pol = this.Pol,
                Email = this.Email,
                AdresaStanovanja = this.AdresaStanovanja,
                TipKorisnika = this.TipKorisnika,
                Active = active
            };
            return korisnik;
        }
        public void Sacuvaj()
        {
            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = Aplikacija.CONNECTION_STRING;
                conn.Open();
                SqlCommand command = conn.CreateCommand();
                command.CommandText = @"INSERT INTO KORISNICI(Korisnicko_ime, Lozinka, Ime, Prezime, Pol, Email, Adresa_stanovanja, Tip_korisnika, Active)" 
                                    + "VALUES(@Korisnicko_ime,@Lozinka,@Ime,@Prezime,@Pol,@Email,@Adresa_stanovanja,@Tip_korisnika,@Active)";
                command.Parameters.Add(new SqlParameter(@"Korisnicko_ime", this.KorisnickoIme));
                command.Parameters.Add(new SqlParameter(@"Lozinka", this.Lozinka));
                command.Parameters.Add(new SqlParameter(@"Ime", this.Ime));
                command.Parameters.Add(new SqlParameter(@"Prezime", this.Prezime));
                command.Parameters.Add(new SqlParameter(@"Pol", this.Pol));
                command.Parameters.Add(new SqlParameter(@"Email", this.Email));
                command.Parameters.Add(new SqlParameter(@"Adresa_stanovanja", this.AdresaStanovanja));
                command.Parameters.Add(new SqlParameter(@"Tip_korisnika", this.TipKorisnika));
                command.Parameters.Add(new SqlParameter(@"Active", 1));
                command.ExecuteNonQuery();

                // conn.Close();
            }
            Aplikacija.Instance.UcitajKorisnikeDS();
        }
        public void Izmena()
        {
            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = Aplikacija.CONNECTION_STRING;
                conn.Open();
                SqlCommand command = conn.CreateCommand();
                command.CommandText = @"UPDATE KORISNICI SET Korisnicko_ime=@Korisnicko_ime, Lozinka=@Lozinka, Ime=@Ime, Prezime=@Prezime, Pol=@Pol, Email=@Email, Adresa_stanovanja=@Adresa_stanovanja, Tip_korisnika=@Tip_korisnika, Active=@Active Where Id=@Id";
                command.Parameters.Add(new SqlParameter(@"Id", this.Id));
                command.Parameters.Add(new SqlParameter(@"Korisnicko_ime", this.KorisnickoIme));
                command.Parameters.Add(new SqlParameter(@"Lozinka", this.Lozinka));
                command.Parameters.Add(new SqlParameter(@"Ime", this.Ime));
                command.Parameters.Add(new SqlParameter(@"Prezime", this.Prezime));
                command.Parameters.Add(new SqlParameter(@"Pol", this.Pol));
                command.Parameters.Add(new SqlParameter(@"Email", this.Email));
                command.Parameters.Add(new SqlParameter(@"Adresa_stanovanja", this.AdresaStanovanja));
                command.Parameters.Add(new SqlParameter(@"Tip_korisnika", this.TipKorisnika));
                command.Parameters.Add(new SqlParameter(@"Active", this.Active));
                command.ExecuteNonQuery();

                // conn.Close();
            }
        }

    }
}

