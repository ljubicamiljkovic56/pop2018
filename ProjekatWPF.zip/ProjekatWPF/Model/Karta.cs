﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjekatWPF.Model
{
    public class Karta : INotifyPropertyChanged, ICloneable
    {
        public int Id { get; set; }
        private String brojLeta;

        public String BrojLeta
        {
            get { return brojLeta; }
            set { brojLeta = value; OnPropertyChanged("BrojLeta"); }
        }
        private String brojSedista;

        public String BrojSedista
        {
            get { return brojSedista; }
            set { brojSedista = value; OnPropertyChanged("BrojSedista"); }
        }
        private String nazivPutnika;

        public String NazivPutnika
        {
            get { return nazivPutnika; }
            set { nazivPutnika = value; OnPropertyChanged("NazivPutnika"); }
        }
        private String  odrediste;

        public String Odrediste
        {
            get { return odrediste; }
            set { odrediste = value; OnPropertyChanged("Odrediste"); }
        }
        private String destinacija;

        public String Destinacija
        {
            get { return destinacija; }
            set { destinacija = value; OnPropertyChanged("Destinacija"); }
        }
        private String kapija;

        public String Kapija
        {
            get { return kapija; }
            set { kapija = value; OnPropertyChanged("Kapija"); }
        }
        private Double ukupnaCenaKarte;

        public Double UkupnaCenaKarte
        {
            get { return ukupnaCenaKarte; }
            set { ukupnaCenaKarte = value; OnPropertyChanged("UkupnaCenaKarte"); }
        }
        private bool active;

        public event PropertyChangedEventHandler PropertyChanged;

        public bool Active
        {
            get { return active; }
            set { active = value; OnPropertyChanged("Active"); }
        }

        public override string ToString()
        {
            return $"BrojLeta {BrojLeta}, BrojSedista {BrojSedista}, NazivPutnika {nazivPutnika},  Odrediste {Odrediste}, Destinacija {Destinacija}, Kapija {Kapija}, ukupnaCenaKarte {ukupnaCenaKarte}";
        }
        private void OnPropertyChanged(String name)
        {
            if(PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(name));
            }
        }

        public object Clone()
        {
            Karta karta = new Karta
            {
                Id = this.Id,
                BrojLeta = this.BrojLeta,
                BrojSedista = this.BrojSedista,
                NazivPutnika = this.NazivPutnika,
                Odrediste = this.Odrediste,
                Destinacija = this.Destinacija,
                Kapija = this.Kapija,
                UkupnaCenaKarte = this.UkupnaCenaKarte,
                Active = this.Active
            };
            return karta;
        }
        public void Sacuvaj()
        {
            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = Aplikacija.CONNECTION_STRING;
                conn.Open();
                SqlCommand command = conn.CreateCommand();
                command.CommandText = @"INSERT INTO KARTE(Broj_leta, Broj_sedista, Naziv_putnika, Odrediste, Destinacija, Kapija, Ukupna_cena_karte, Active)" 
                                    + "VALUES(@Broj_leta,@Broj_sedista,@Naziv_putnika,@Odrediste,@Destinacija,@Kapija,@Ukupna_cena_karte,@Active)";
                command.Parameters.Add(new SqlParameter(@"Broj_leta", this.BrojLeta));
                command.Parameters.Add(new SqlParameter(@"Broj_sedista", this.BrojSedista));
                command.Parameters.Add(new SqlParameter(@"Naziv_putnika", this.NazivPutnika));
                command.Parameters.Add(new SqlParameter(@"Odrediste", this.Odrediste));
                command.Parameters.Add(new SqlParameter(@"Destinacija", this.Destinacija));
                command.Parameters.Add(new SqlParameter(@"Kapija", this.Kapija));
                command.Parameters.Add(new SqlParameter(@"Ukupna_cena_karte", this.UkupnaCenaKarte));
                command.Parameters.Add(new SqlParameter(@"Active", 1));
                command.ExecuteNonQuery();

                // conn.Close();
            }
            Aplikacija.Instance.UcitajKarteDS();
        }
        public void Izmena()
        {
            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = Aplikacija.CONNECTION_STRING;
                conn.Open();
                SqlCommand command = conn.CreateCommand();
                command.CommandText = @"UPDATE KARTE SET Broj_leta=@Broj_leta, Broj_sedista=@Broj_sedista, Naziv_putnika=@Naziv_putnika, Odrediste=@Odrediste, Destinacija=@Destinacija, Kapija=@Kapija, Ukupna_cena_karte=@Ukupna_cena_karte, Active=@Active Where Id=@Id";
                command.Parameters.Add(new SqlParameter(@"Id", this.Id));
                command.Parameters.Add(new SqlParameter(@"Broj_leta", this.BrojLeta));
                command.Parameters.Add(new SqlParameter(@"Broj_sedista", this.BrojSedista));
                command.Parameters.Add(new SqlParameter(@"Naziv_putnika", this.NazivPutnika));
                command.Parameters.Add(new SqlParameter(@"Odrediste", this.Odrediste));
                command.Parameters.Add(new SqlParameter(@"Destinacija", this.Destinacija));
                command.Parameters.Add(new SqlParameter(@"Kapija", this.Kapija));
                command.Parameters.Add(new SqlParameter(@"Ukupna_cena_karte", this.UkupnaCenaKarte));
                command.Parameters.Add(new SqlParameter(@"Active", this.Active));
                command.ExecuteNonQuery();

                // conn.Close();
            }
        }
    }
}
