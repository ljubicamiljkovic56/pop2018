﻿using ProjekatWPF.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProjekatWPF
{
    /// <summary>
    /// Interaction logic for PutnikLetovi.xaml
    /// </summary>
    public partial class PutnikLetovi : Window
    {
        ICollectionView view;
        public PutnikLetovi()
        {
            InitializeComponent();
            view = CollectionViewSource.GetDefaultView(Aplikacija.Instance.Letovi);
            DGLetoviPutnik.ItemsSource = view;
            DGLetoviPutnik.IsSynchronizedWithCurrentItem = true;
            DGLetoviPutnik.ColumnWidth = new DataGridLength(1, DataGridLengthUnitType.Star);
        }
        private void BtnNazad_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }
    }
}
