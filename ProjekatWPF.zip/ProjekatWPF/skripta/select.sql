﻿CREATE TABLE [dbo].[Aerodromi] (
    [Id]     INT          IDENTITY (1, 1) NOT NULL,
    [Naziv]  VARCHAR (50) NOT NULL,
    [Grad]   VARCHAR (50) NOT NULL,
    [Sifra]  VARCHAR (50) NOT NULL,
    [Active] BIT          NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);
CREATE TABLE [dbo].[Aviokompanije] (
    [Id]     INT          IDENTITY (1, 1) NOT NULL,
    [Sifra]  VARCHAR (50) NOT NULL,
    [Active] BIT          NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);
CREATE TABLE [dbo].[Avioni] (
    [Id]                  INT          IDENTITY (1, 1) NOT NULL,
    [Broj_leta]           VARCHAR (50) NOT NULL,
    [Naziv_aviokompanije] VARCHAR (50) NOT NULL,
    [Active]              BIT          NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);
CREATE TABLE [dbo].[Karte] (
    [Id]                INT          IDENTITY (1, 1) NOT NULL,
    [Broj_leta]         VARCHAR (50) NOT NULL,
    [Broj_sedista]      VARCHAR (50) NOT NULL,
    [Naziv_putnika]     VARCHAR (50) NOT NULL,
    [Odrediste]         VARCHAR (50) NOT NULL,
    [Destinacija]       VARCHAR (50) NOT NULL,
    [Kapija]            VARCHAR (50) NOT NULL,
    [Ukupna_cena_karte] FLOAT (53)   NOT NULL,
    [Active]            BIT          NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);
CREATE TABLE [dbo].[Korisnici] (
    [Id]                INT          IDENTITY (1, 1) NOT NULL,
    [Korisnicko_ime]    VARCHAR (50) NOT NULL,
    [Lozinka]           VARCHAR (50) NOT NULL,
    [Ime]               VARCHAR (50) NOT NULL,
    [Prezime]           VARCHAR (50) NOT NULL,
    [Pol]               CHAR (10)    NOT NULL,
    [Email]             VARCHAR (50) NOT NULL,
    [Adresa_stanovanja] VARCHAR (50) NOT NULL,
    [Tip_korisnika]     VARCHAR (50) NOT NULL,
    [Active]            BIT          NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);
CREATE TABLE [dbo].[Letovi] (
    [Id]              INT          IDENTITY (1, 1) NOT NULL,
    [Broj_leta]       VARCHAR (50) NOT NULL,
    [VremePolaska]    DATETIME     NOT NULL,
    [VremeDolaska]    DATETIME     NOT NULL,
    [Odrediste]       VARCHAR (50) NOT NULL,
    [Destinacija]     VARCHAR (50) NOT NULL,
    [Cena_leta]       FLOAT (53)   NOT NULL,
    [AviokompanijaId] INT          NOT NULL,
    [Pilot]           VARCHAR (50) NOT NULL,
    [Active]          BIT          NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);
CREATE TABLE [dbo].[Sedista] (
    [Id]           INT       IDENTITY (1, 1) NOT NULL,
    [Broj_sedista] CHAR (10) NOT NULL,
    [Active]       BIT       NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

INSERT INTO Aerodromi(Naziv,Grad,Sifra,Active) VALUES ('Nikola Tesla','Beograd','BEG',1)
INSERT INTO Aerodromi(Naziv,Grad,Sifra,Active) VALUES ('London Aerodrom','London','LON',1)
INSERT INTO Aerodromi(Naziv,Grad,Sifra,Active) VALUES ('Amsterdam Aerodrom','Amsterdam','AMS',1)
INSERT INTO Aerodromi(Naziv,Grad,Sifra,Active) VALUES ('Leonardo Da Vinci','Rim','RIM',1)
INSERT INTO Aerodromi(Naziv,Grad,Sifra,Active) VALUES ('Narita','Tokijo','TOK',1)

INSERT INTO Aviokompanije(Sifra,Active) VALUES ('A1',1);
INSERT INTO Aviokompanije(Sifra,Active) VALUES ('A2',1);
INSERT INTO Aviokompanije(Sifra,Active) VALUES ('A3',1);
INSERT INTO Aviokompanije(Sifra,Active) VALUES ('A4',1);
INSERT INTO Aviokompanije(Sifra,Active) VALUES ('A5',1);


INSERT INTO Avioni(Broj_leta,Naziv_aviokompanije,Active) VALUES ('1','Air Serbia',1);
INSERT INTO Avioni(Broj_leta,Naziv_aviokompanije,Active) VALUES ('2','British Airlines',1);
INSERT INTO Avioni(Broj_leta,Naziv_aviokompanije,Active) VALUES ('3','Nederlands Air',1);
INSERT INTO Avioni(Broj_leta,Naziv_aviokompanije,Active) VALUES ('4','Italia Airlines',1);
INSERT INTO Avioni(Broj_leta,Naziv_aviokompanije,Active) VALUES ('5','Japan Air',1);


INSERT INTO Karte(Broj_leta,Broj_sedista,Naziv_putnika,Odrediste,Destinacija,Kapija,Ukupna_cena_karte,Active) 
			VALUES ('1','11','ekonomski','BEG','LON','G1',20000.00,1)
INSERT INTO Karte(Broj_leta,Broj_sedista,Naziv_putnika,Odrediste,Destinacija,Kapija,Ukupna_cena_karte,Active)
			VALUES ('2','12','biznis','BEG','AMS','G2',18000.00,1)
INSERT INTO Karte(Broj_leta,Broj_sedista,Naziv_putnika,Odrediste,Destinacija,Kapija,Ukupna_cena_karte,Active)
			VALUES ('3','13','ekonomski','LON','BEG','G3',18500.00,1)
INSERT INTO Karte(Broj_leta,Broj_sedista,Naziv_putnika,Odrediste,Destinacija,Kapija,Ukupna_cena_karte,Active)
			VALUES ('4','14','biznis','BEG','RIM','G4',19000.00,1)
INSERT INTO Karte(Broj_leta,Broj_sedista,Naziv_putnika,Odrediste,Destinacija,Kapija,Ukupna_cena_karte,Active)
			VALUES ('5','15','ekonomski','BEG','TOK','G5',22000.00,1)

INSERT INTO Korisnici(Korisnicko_ime,Lozinka,Ime,Prezime,Pol,Email,Adresa_stanovanja,Tip_korisnika,Active) VALUES ('pera','pera','Pera','Peric','MUSKI','pera@yahoo.com','Novi Sad','ADMINISTRATOR',1)
INSERT INTO Korisnici(Korisnicko_ime,Lozinka,Ime,Prezime,Pol,Email,Adresa_stanovanja,Tip_korisnika,Active) VALUES ('mika','mika','Mika','Mikic','MUSKI','mika@gmail.com','Beograd','PUTNIK',1)
INSERT INTO Korisnici(Korisnicko_ime,Lozinka,Ime,Prezime,Pol,Email,Adresa_stanovanja,Tip_korisnika,Active) VALUES ('zika','zika','Zika','Zikic','MUSKI','zika@hotmail.com','Subotica','PUTNIK',1)
INSERT INTO Korisnici(Korisnicko_ime,Lozinka,Ime,Prezime,Pol,Email,Adresa_stanovanja,Tip_korisnika,Active) VALUES ('maki','maki','Mara','Maric','ZENSKI','mara@gmail.com','Zemun','PUTNIK',1)
INSERT INTO Korisnici(Korisnicko_ime,Lozinka,Ime,Prezime,Pol,Email,Adresa_stanovanja,Tip_korisnika,Active) VALUES ('ana','ana','Ana','Antic','ZENSKI','ana@gmail.com','Zrenjanin','ADMINISTRATOR',1)


INSERT INTO Letovi(Broj_leta,VremePolaska,VremeDolaska,Odrediste,Destinacija,Cena_leta,AviokompanijaId,Pilot,Active) VALUES (1,GETDATE(),GETDATE(),'BEG','LON',20000.00,1,'P1',1)
INSERT INTO Letovi(Broj_leta,VremePolaska,VremeDolaska,Odrediste,Destinacija,Cena_leta,AviokompanijaId,Pilot,Active) VALUES (2,GETDATE(),GETDATE(),'BEG','AMS',18000.00,2,'P2',1)
INSERT INTO Letovi(Broj_leta,VremePolaska,VremeDolaska,Odrediste,Destinacija,Cena_leta,AviokompanijaId,Pilot,Active) VALUES (3,GETDATE(),GETDATE(),'LON','BEG',18500.00,3,'P3',1)
INSERT INTO Letovi(Broj_leta,VremePolaska,VremeDolaska,Odrediste,Destinacija,Cena_leta,AviokompanijaId,Pilot,Active) VALUES (4,GETDATE(),GETDATE(),'BEG','RIM',19000.00,4,'P4',1)
INSERT INTO Letovi(Broj_leta,VremePolaska,VremeDolaska,Odrediste,Destinacija,Cena_leta,AviokompanijaId,Pilot,Active) VALUES (5,GETDATE(),GETDATE(),'BEG','TOK',22000.00,5,'P5',1)

INSERT INTO Sedista(Broj_sedista,Active) VALUES ('11',1)
INSERT INTO Sedista(Broj_sedista,Active) VALUES ('12',1)
INSERT INTO Sedista(Broj_sedista,Active) VALUES ('13',1)
INSERT INTO Sedista(Broj_sedista,Active) VALUES ('14',1)
INSERT INTO Sedista(Broj_sedista,Active) VALUES ('15',1)


Select * From Aerodromi
Select * From Aviokompanije
Select * From Avioni
Select * From Karte
Select * From Korisnici
Select * From Letovi
Select * From Sedista
