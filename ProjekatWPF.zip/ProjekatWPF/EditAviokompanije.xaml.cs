﻿using ProjekatWPF.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProjekatWPF
{
    /// <summary>
    /// Interaction logic for EditAviokompanije.xaml
    /// </summary>
    public partial class EditAviokompanije : Window
    {
        ICollectionView view1;
        public enum Opcija { DODAVANJE, IZMENA};
        private Aviokompanija aviokompanija;
        private Opcija opcija;
        public EditAviokompanije(Aviokompanija aviokompanija, Opcija opcija)
        {
            InitializeComponent();
            this.aviokompanija = aviokompanija;
            this.opcija = opcija;

            this.DataContext = aviokompanija;
            DGListaLetova.ItemsSource = aviokompanija.Letovi;

            if (opcija.Equals(Opcija.IZMENA))
            {
                TxtSifra.IsEnabled = false;
            }
            InitializeComponent();
            view1 = CollectionViewSource.GetDefaultView(Aplikacija.Instance.Letovi);
            DGListaLetova.ItemsSource = view1;
            DGListaLetova.IsSynchronizedWithCurrentItem = true;
            DGListaLetova.ColumnWidth = new DataGridLength(1, DataGridLengthUnitType.Star);
           
        }
        private void BtnSacuvaj_Click(Object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
            if(opcija.Equals(Opcija.DODAVANJE) && !PostojiAviokompanija(aviokompanija.Sifra))
            {
                aviokompanija.Sacuvaj();
            }
        }

        private void BtnOdustani_Click(Object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }
        private bool PostojiAviokompanija(String sifra)
        {
            foreach(Aviokompanija aviokompanija in Aplikacija.Instance.Aviokompanije)
            {
                if(aviokompanija.Sifra.Equals(sifra))
                {
                    return true;
                }
            }
            return false;
        }
    }
}
